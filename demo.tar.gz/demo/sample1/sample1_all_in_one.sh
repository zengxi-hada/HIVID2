echo "
## step 2" >&2
perl /home/xiz978/bin/HZAU_bin/HIVID2/main.pl -o /home/xiz978/project/HIVID2/sample1 -l /home/xiz978/project/HIVID2/sample1/list  -c /home/xiz978/project/HIVID2/ConfigHPV83_hg38 -stp 2
sh /home/xiz978/project/HIVID2/sample1/step2/sample1/trimmomatic.sh

echo "
## step 3" >&2
perl /home/xiz978/bin/HZAU_bin/HIVID2/main.pl -o /home/xiz978/project/HIVID2/sample1 -l /home/xiz978/project/HIVID2/sample1/list  -c /home/xiz978/project/HIVID2/ConfigHPV83_hg38 -stp 3
sh /home/xiz978/project/HIVID2/sample1/step3/sample1/Human_virus_soap.sh
sh /home/xiz978/project/HIVID2/sample1/step3/sample1/station.sh

echo "
## step 4" >&2
perl /home/xiz978/bin/HZAU_bin/HIVID2/main.pl -o /home/xiz978/project/HIVID2/sample1 -l /home/xiz978/project/HIVID2/sample1/list  -c /home/xiz978/project/HIVID2/ConfigHPV83_hg38 -stp 4 -filter -fa1 /n/data1/bch/genetics/lee/xi/ref/fasta/hg38/bwa_index/hg38.fa -fa2 /n/data1/bch/genetics/lee/xi/ref/fasta/hpv/bwa_index/hpvall.fa
sh /home/xiz978/project/HIVID2/sample1/step4/sample1/bwa_mem_and_call_integration_sites.sh
sh /home/xiz978/bin/HZAU_bin/HIVID2/run_update_breakpoints.sh /home/xiz978/project/HIVID2/sample1 sample1 /home/xiz978/bin/HZAU_bin/HIVID2 /n/data1/bch/genetics/lee/xi/ref/fasta/hg38/bwa_index/hg38.fa /n/data1/bch/genetics/lee/xi/ref/fasta/hpv/bwa_index/hpvall.fa