#!/bin/bash
#PBS -N trimmomatic.sh
#PBS -l nodes=1:ppn=5
#PBS –l walltime=100:00:00
#PBS –l mem=10G
#PBS -q batch
#PBS -V
cd $PBS_O_WORKDIR
date
java -jar /home/xiz978/bin/HZAU_bin/HIVID2/Trimmomatic-0.39/trimmomatic-0.39.jar PE -phred33 /home/xiz978/project/HIVID2/DemoData/sample1_R302_CapNGS.clean_R1.fq.gz /home/xiz978/project/HIVID2/DemoData/sample1_R302_CapNGS.clean_R2.fq.gz /home/xiz978/project/HIVID2/sample1/step2/sample1/sample1_R302_CapNGS.clean_R1.fq.trimmo.paired.gz /home/xiz978/project/HIVID2/sample1/step2/sample1/sample1_R302_CapNGS.clean_R1.fq.trimmo.unpaired.gz /home/xiz978/project/HIVID2/sample1/step2/sample1/sample1_R302_CapNGS.clean_R2.fq.trimmo.paired.gz /home/xiz978/project/HIVID2/sample1/step2/sample1/sample1_R302_CapNGS.clean_R2.fq.trimmo.unpaired.gz ILLUMINACLIP:/home/xiz978/bin/HZAU_bin/HIVID2/Trimmomatic-0.39/adapters/TruSeq3-PE.fa:2:30:10 LEADING:3 TRAILING:3 SLIDINGWINDOW:4:15 MINLEN:60
java -jar /home/xiz978/bin/HZAU_bin/HIVID2/Trimmomatic-0.39/trimmomatic-0.39.jar PE -phred33 /home/xiz978/project/HIVID2/DemoData/sample1_R302_CapNGS.clean_R1.fq.gz /home/xiz978/project/HIVID2/DemoData/sample1_R302_CapNGS.clean_R2.fq.gz /home/xiz978/project/HIVID2/sample1/step2/sample1/sample1_R302_CapNGS.clean_R1.fq.trimmo.paired1.gz /home/xiz978/project/HIVID2/sample1/step2/sample1/sample1_R302_CapNGS.clean_R1.fq.trimmo.unpaired1.gz /home/xiz978/project/HIVID2/sample1/step2/sample1/sample1_R302_CapNGS.clean_R2.fq.trimmo.paired1.gz /home/xiz978/project/HIVID2/sample1/step2/sample1/sample1_R302_CapNGS.clean_R2.fq.trimmo.unpaired1.gz ILLUMINACLIP:/home/xiz978/bin/HZAU_bin/HIVID2/Trimmomatic-0.39/adapters/TruSeq3-PE.fa:2:30:10 LEADING:0 TRAILING:0 SLIDINGWINDOW:4:0
date
