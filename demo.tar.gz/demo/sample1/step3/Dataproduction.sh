perl /home/xiz978/bin/HZAU_bin/HIVID2/HBV_Dataproduction.pl /home/xiz978/project/HIVID2/sample1/step3/allsample.list Dataproduction.xls
