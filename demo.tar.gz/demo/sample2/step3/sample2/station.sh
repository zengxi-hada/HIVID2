#!/bin/bash
#PBS -N station.sh
#PBS -l nodes=1:ppn=5
#PBS –l walltime=100:00:00
#PBS –l mem=10G
#PBS -q batch
#PBS -V
cd $PBS_O_WORKDIR

date
perl /home/xiz978/bin/HZAU_bin/HIVID2/new_HBV_human_soap.pl -reads_assembly /home/xiz978/bin/HZAU_bin/HIVID2/overlap_pair_trim.new -margefa_qua /home/xiz978/bin/HZAU_bin/HIVID2/margefa_qua.pl -hp /home/xiz978/project/HIVID2/sample2/step3/sample2/SOAP/Human_sample2.pair.soap -hs /home/xiz978/project/HIVID2/sample2/step3/sample2/SOAP/Human_sample2.single.soap -hu /home/xiz978/project/HIVID2/sample2/step3/sample2/SOAP/Human_sample2.unmap.soap -bp /home/xiz978/project/HIVID2/sample2/step3/sample2/SOAP/virus_sample2.pair.soap -bs /home/xiz978/project/HIVID2/sample2/step3/sample2/SOAP/virus_sample2.single.soap -bu /home/xiz978/project/HIVID2/sample2/step3/sample2/SOAP/virus_sample2.unmap.soap -pe /home/xiz978/project/HIVID2/sample2/step3/sample2/station_pair_end/sample2_pe_pe.gz -se /home/xiz978/project/HIVID2/sample2/step3/sample2/station_pair_end/sample2_se_se.gz -sb /home/xiz978/project/HIVID2/sample2/step3/sample2/station_pair_end/sample2_virus_un.gz -sh /home/xiz978/project/HIVID2/sample2/step3/sample2/station_pair_end/sample2_Human_un.gz -un /home/xiz978/project/HIVID2/sample2/step3/sample2/station_pair_end/sample2_un_un.gz  -stat /home/xiz978/project/HIVID2/sample2/step3/sample2/sample2.stat -f1 /home/xiz978/project/HIVID2/sample2/step2/sample2/20C211080_R302_CapNGS.clean_R1.fq.h100k.trimmo.paired.gz -f2 /home/xiz978/project/HIVID2/sample2/step2/sample2/20C211080_R302_CapNGS.clean_R2.fq.h100k.trimmo.paired.gz -o /home/xiz978/project/HIVID2/sample2/step3/sample2/reads_assemble_pair-end 

perl /home/xiz978/bin/HZAU_bin/HIVID2/new_HBV_human_soap_se.pl -hs /home/xiz978/project/HIVID2/sample2/step3/sample2/SOAP/Human_sample2.se.soap -hu /home/xiz978/project/HIVID2/sample2/step3/sample2/SOAP/Human_sample2.unmap.se.soap -bs /home/xiz978/project/HIVID2/sample2/step3/sample2/SOAP/virus_sample2.se.soap -bu /home/xiz978/project/HIVID2/sample2/step3/sample2/SOAP/virus_sample2.unmap.se.soap -se /home/xiz978/project/HIVID2/sample2/step3/sample2/station_single_end/sample2_se_se.gz -sb /home/xiz978/project/HIVID2/sample2/step3/sample2/station_single_end/sample2_virus_un.gz -sh /home/xiz978/project/HIVID2/sample2/step3/sample2/station_single_end/sample2_Human_un.gz -un /home/xiz978/project/HIVID2/sample2/step3/sample2/station_single_end/sample2_un_un.gz -stat /home/xiz978/project/HIVID2/sample2/step3/sample2/sample2.stat -f1 /home/xiz978/project/HIVID2/sample2/step2/sample2/20C211080_R302_CapNGS.clean.fq.h100k.trimmo.unpaired.gz -o /home/xiz978/project/HIVID2/sample2/step3/sample2/reads_unassemble_single-end 

perl /home/xiz978/bin/HZAU_bin/HIVID2/cal_dup_rate_soap.pl /home/xiz978/project/HIVID2/sample2/step3/sample2/SOAP/Human_sample2.pair.soap /home/xiz978/project/HIVID2/sample2/step1/sample.list > /home/xiz978/project/HIVID2/sample2/step3/sample2/SOAP/Human_sample2.pair.soap.uniq_rate
date
