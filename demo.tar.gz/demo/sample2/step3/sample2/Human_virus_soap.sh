#!/bin/bash
#PBS -N Human_virus_soap.sh
#PBS -l nodes=1:ppn=5
#PBS –l walltime=100:00:00
##PBS –l mem=10G
#PBS -q batch
#PBS -V
cd $PBS_O_WORKDIR
date
cat /home/xiz978/project/HIVID2/sample2/step2/sample2/20C211080_R302_CapNGS.clean_R1.fq.h100k.trimmo.unpaired.gz /home/xiz978/project/HIVID2/sample2/step2/sample2/20C211080_R302_CapNGS.clean_R2.fq.h100k.trimmo.unpaired.gz > /home/xiz978/project/HIVID2/sample2/step2/sample2/20C211080_R302_CapNGS.clean.fq.h100k.trimmo.unpaired.gz;

/home/xiz978/bin/HZAU_bin/HIVID2/soap/soap2.21 -a /home/xiz978/project/HIVID2/sample2/step2/sample2/20C211080_R302_CapNGS.clean_R1.fq.h100k.trimmo.paired.gz -b /home/xiz978/project/HIVID2/sample2/step2/sample2/20C211080_R302_CapNGS.clean_R2.fq.h100k.trimmo.paired.gz -D /n/data1/bch/genetics/lee/xi/ref/fasta/hg38/soap2_index/hg38.fa.index -o /home/xiz978/project/HIVID2/sample2/step3/sample2/SOAP/Human_sample2.pair.soap -2 /home/xiz978/project/HIVID2/sample2/step3/sample2/SOAP/Human_sample2.single.soap -u /home/xiz978/project/HIVID2/sample2/step3/sample2/SOAP/Human_sample2.unmap.soap -m 205 -x 295 -p 8 -l 50 -v 5 -r 1

/home/xiz978/bin/HZAU_bin/HIVID2/soap/soap2.21 -a /home/xiz978/project/HIVID2/sample2/step2/sample2/20C211080_R302_CapNGS.clean.fq.h100k.trimmo.unpaired.gz -D /n/data1/bch/genetics/lee/xi/ref/fasta/hg38/soap2_index/hg38.fa.index -o /home/xiz978/project/HIVID2/sample2/step3/sample2/SOAP/Human_sample2.se.soap -u /home/xiz978/project/HIVID2/sample2/step3/sample2/SOAP/Human_sample2.unmap.se.soap -p 8 -l 50 -v 5 -r 1

/home/xiz978/bin/HZAU_bin/HIVID2/soap/soap2.21 -a /home/xiz978/project/HIVID2/sample2/step2/sample2/20C211080_R302_CapNGS.clean_R1.fq.h100k.trimmo.paired.gz -b /home/xiz978/project/HIVID2/sample2/step2/sample2/20C211080_R302_CapNGS.clean_R2.fq.h100k.trimmo.paired.gz -D /n/data1/bch/genetics/lee/xi/ref/fasta/hpv/soap2_index/hpvall.fa.index -o /home/xiz978/project/HIVID2/sample2/step3/sample2/SOAP/virus_sample2.pair.soap -2 /home/xiz978/project/HIVID2/sample2/step3/sample2/SOAP/virus_sample2.single.soap -u /home/xiz978/project/HIVID2/sample2/step3/sample2/SOAP/virus_sample2.unmap.soap -m 205 -x 295 -p 8 -l 50 -v 5 -r 1

/home/xiz978/bin/HZAU_bin/HIVID2/soap/soap2.21 -a /home/xiz978/project/HIVID2/sample2/step2/sample2/20C211080_R302_CapNGS.clean.fq.h100k.trimmo.unpaired.gz -D /n/data1/bch/genetics/lee/xi/ref/fasta/hpv/soap2_index/hpvall.fa.index -o /home/xiz978/project/HIVID2/sample2/step3/sample2/SOAP/virus_sample2.se.soap -u /home/xiz978/project/HIVID2/sample2/step3/sample2/SOAP/virus_sample2.unmap.se.soap -p 8 -l 50 -v 5 -r 1

date
